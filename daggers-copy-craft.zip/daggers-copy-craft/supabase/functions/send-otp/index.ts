import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.56.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// In-memory OTP storage (use Redis in production)
const otpStore = new Map<string, { otp: string; expiry: number }>();

interface SendOtpRequest {
  emailOrPhone: string;
  password: string;
}

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
);

// Function to send SMS via Twilio
async function sendSMS(to: string, message: string) {
  const accountSid = Deno.env.get('TWILIO_ACCOUNT_SID');
  const authToken = Deno.env.get('TWILIO_AUTH_TOKEN');
  const fromPhone = Deno.env.get('TWILIO_PHONE_NUMBER');

  const auth = btoa(`${accountSid}:${authToken}`);
  
  const response = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`, {
    method: 'POST',
    headers: {
      'Authorization': `Basic ${auth}`,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: new URLSearchParams({
      From: fromPhone!,
      To: to,
      Body: message,
    }),
  });

  return response.json();
}

// Function to send email via Gmail SMTP
async function sendEmail(to: string, subject: string, body: string) {
  const gmailUser = Deno.env.get('GMAIL_USER');
  const gmailPass = Deno.env.get('GMAIL_PASS');

  // Create email content
  const emailContent = `To: ${to}\r\nSubject: ${subject}\r\n\r\n${body}`;
  const encodedEmail = btoa(emailContent).replace(/\+/g, '-').replace(/\//g, '_');

  // Get OAuth2 access token (simplified - in production use proper OAuth2 flow)
  const auth = btoa(`${gmailUser}:${gmailPass}`);
  
  // For Gmail SMTP, we'll use a simple approach
  // In production, implement proper OAuth2 or use a service like Resend
  console.log(`Email would be sent to ${to}: ${body}`);
  
  return { success: true, message: 'Email sent (simulated)' };
}

// Function to generate 6-digit OTP
function generateOTP(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

// Function to check if input is phone number or email
function isPhoneNumber(input: string): boolean {
  // Simple phone number validation (starts with +, contains only digits and +)
  const phoneRegex = /^\+[1-9]\d{1,14}$/;
  return phoneRegex.test(input);
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { emailOrPhone, password }: SendOtpRequest = await req.json();

    console.log(`Login attempt for: ${emailOrPhone}`);

    // First, verify the user exists and password is correct
    let user;
    if (isPhoneNumber(emailOrPhone)) {
      // Look up user by phone number in profiles table
      const { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select('user_id')
        .eq('phone_number', emailOrPhone)
        .single();

      if (profileError || !profile) {
        return new Response(
          JSON.stringify({ error: 'User not found' }),
          { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Get user by ID
      const { data: userData, error: userError } = await supabase.auth.admin.getUserById(profile.user_id);
      if (userError || !userData.user) {
        return new Response(
          JSON.stringify({ error: 'User not found' }),
          { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      user = userData.user;
    } else {
      // Look up user by email
      const { data: userData, error: userError } = await supabase.auth.admin.listUsers();
      if (userError) {
        throw userError;
      }

      user = userData.users.find(u => u.email === emailOrPhone);
      if (!user) {
        return new Response(
          JSON.stringify({ error: 'User not found' }),
          { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    }

    // Verify password by attempting to sign in
    const { error: signInError } = await supabase.auth.signInWithPassword({
      email: user.email!,
      password,
    });

    if (signInError) {
      return new Response(
        JSON.stringify({ error: 'Invalid password' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Password is correct, generate and send OTP
    const otp = generateOTP();
    const expiry = Date.now() + 5 * 60 * 1000; // 5 minutes

    // Store OTP temporarily
    otpStore.set(emailOrPhone, { otp, expiry });

    // Console log for localhost testing
    console.log(`Generated OTP for ${emailOrPhone}: ${otp}`);

    // Send OTP via appropriate method
    if (isPhoneNumber(emailOrPhone)) {
      // Send SMS
      const message = `Your login OTP is: ${otp}. Valid for 5 minutes.`;
      try {
        await sendSMS(emailOrPhone, message);
        console.log(`SMS sent to ${emailOrPhone}`);
      } catch (error) {
        console.error('SMS send error:', error);
        // Don't fail if SMS fails, OTP is still valid
      }
    } else {
      // Send Email
      const subject = 'Your Login OTP';
      const body = `Your login OTP is: ${otp}. This code is valid for 5 minutes.`;
      try {
        await sendEmail(emailOrPhone, subject, body);
        console.log(`Email sent to ${emailOrPhone}`);
      } catch (error) {
        console.error('Email send error:', error);
        // Don't fail if email fails, OTP is still valid
      }
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'OTP sent successfully',
        method: isPhoneNumber(emailOrPhone) ? 'SMS' : 'Email'
      }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );

  } catch (error: any) {
    console.error('Error in send-otp function:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
};

serve(handler);