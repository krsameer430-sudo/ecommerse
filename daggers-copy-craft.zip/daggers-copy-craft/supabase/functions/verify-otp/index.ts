import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.56.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// In-memory OTP storage (should match send-otp function)
const otpStore = new Map<string, { otp: string; expiry: number }>();

interface VerifyOtpRequest {
  emailOrPhone: string;
  otp: string;
}

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
);

// Function to check if input is phone number or email
function isPhoneNumber(input: string): boolean {
  const phoneRegex = /^\+[1-9]\d{1,14}$/;
  return phoneRegex.test(input);
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { emailOrPhone, otp }: VerifyOtpRequest = await req.json();

    console.log(`OTP verification attempt for: ${emailOrPhone}`);

    // Get stored OTP
    const storedOtpData = otpStore.get(emailOrPhone);
    
    if (!storedOtpData) {
      return new Response(
        JSON.stringify({ error: 'No OTP found. Please request a new one.' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Check if OTP has expired
    if (Date.now() > storedOtpData.expiry) {
      otpStore.delete(emailOrPhone); // Clean up expired OTP
      return new Response(
        JSON.stringify({ error: 'OTP has expired. Please request a new one.' }),
        { status: 410, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Verify OTP
    if (otp !== storedOtpData.otp) {
      return new Response(
        JSON.stringify({ error: 'Invalid OTP. Please try again.' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // OTP is valid, clean it up and proceed with login
    otpStore.delete(emailOrPhone);

    // Get user information
    let user;
    if (isPhoneNumber(emailOrPhone)) {
      // Look up user by phone number in profiles table
      const { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select('user_id')
        .eq('phone_number', emailOrPhone)
        .single();

      if (profileError || !profile) {
        return new Response(
          JSON.stringify({ error: 'User not found' }),
          { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Get user by ID
      const { data: userData, error: userError } = await supabase.auth.admin.getUserById(profile.user_id);
      if (userError || !userData.user) {
        return new Response(
          JSON.stringify({ error: 'User not found' }),
          { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      user = userData.user;
    } else {
      // Look up user by email
      const { data: userData, error: userError } = await supabase.auth.admin.listUsers();
      if (userError) {
        throw userError;
      }

      user = userData.users.find(u => u.email === emailOrPhone);
      if (!user) {
        return new Response(
          JSON.stringify({ error: 'User not found' }),
          { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    }

    // Generate a session token for the user
    const { data: sessionData, error: sessionError } = await supabase.auth.admin.generateLink({
      type: 'magiclink',
      email: user.email!,
    });

    if (sessionError) {
      throw sessionError;
    }

    console.log(`OTP verification successful for ${emailOrPhone}`);

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'OTP verified successfully',
        user: {
          id: user.id,
          email: user.email,
          // Don't send sensitive data
        },
        session: sessionData
      }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );

  } catch (error: any) {
    console.error('Error in verify-otp function:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
};

serve(handler);