-- Update existing user to admin role
UPDATE profiles 
SET role = 'admin' 
WHERE user_id = 'c5b007e7-ab9f-4ea2-9d7f-e6ee61584cfc';

-- Also ensure we have a way to create admin users in the future
-- You can manually update any user to admin role using this pattern:
-- UPDATE profiles SET role = 'admin' WHERE user_id = 'USER_ID_HERE';