import { useEffect, useCallback } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';

export const useSessionManager = () => {
  const { session, signOut } = useAuth();

  // Check if session is expired
  const isSessionExpired = useCallback(() => {
    if (!session) return false;
    
    const now = Math.floor(Date.now() / 1000);
    const expiresAt = session.expires_at;
    
    if (!expiresAt) return false;
    
    // Consider session expired if it expires in the next 5 minutes
    return expiresAt - now < 300;
  }, [session]);

  // Refresh session if needed
  const refreshSession = useCallback(async () => {
    try {
      const { data, error } = await supabase.auth.refreshSession();
      
      if (error) {
        console.error('Session refresh failed:', error);
        toast({
          title: "Session Expired",
          description: "Please log in again to continue.",
          variant: "destructive",
        });
        await signOut();
        return false;
      }
      
      return true;
    } catch (error) {
      console.error('Session refresh error:', error);
      return false;
    }
  }, [signOut]);

  // Set up automatic session monitoring
  useEffect(() => {
    if (!session) return;

    // Check session every 5 minutes
    const interval = setInterval(() => {
      if (isSessionExpired()) {
        refreshSession();
      }
    }, 5 * 60 * 1000); // 5 minutes

    return () => clearInterval(interval);
  }, [session, isSessionExpired, refreshSession]);

  // Handle visibility change (when user comes back to tab)
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible' && session && isSessionExpired()) {
        refreshSession();
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => document.removeEventListener('visibilitychange', handleVisibilityChange);
  }, [session, isSessionExpired, refreshSession]);

  return {
    isSessionExpired: isSessionExpired(),
    refreshSession,
  };
};