import { useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';

interface UseAuthGuardOptions {
  requiredRole?: 'admin' | 'customer';
  redirectTo?: string;
  requireAuth?: boolean;
}

export const useAuthGuard = (options: UseAuthGuardOptions = {}) => {
  const { 
    requiredRole, 
    redirectTo = '/auth', 
    requireAuth = true 
  } = options;
  
  const { user, userProfile, isLoading, hasRole } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    // Don't redirect while loading
    if (isLoading) return;

    // Check if authentication is required
    if (requireAuth && !user) {
      toast({
        title: "Authentication Required",
        description: "Please log in to access this page.",
        variant: "destructive",
      });
      navigate(redirectTo, { state: { from: location }, replace: true });
      return;
    }

    // Check role requirements
    if (requiredRole && user && !hasRole(requiredRole)) {
      toast({
        title: "Access Denied", 
        description: `This page requires ${requiredRole} access.`,
        variant: "destructive",
      });
      
      // Redirect based on user's actual role
      const fallbackRedirect = userProfile?.role === 'admin' ? '/dashboard' : '/shop';
      navigate(fallbackRedirect, { replace: true });
      return;
    }
  }, [user, userProfile, isLoading, requiredRole, hasRole, navigate, location, redirectTo, requireAuth]);

  return {
    isAuthenticated: !!user,
    isAuthorized: !requiredRole || hasRole(requiredRole),
    userRole: userProfile?.role,
    isLoading
  };
};