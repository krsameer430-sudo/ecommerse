import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Package, ShoppingCart, Users, TrendingUp, AlertTriangle, DollarSign, Calendar, ArrowUpDown } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface KPIData {
  todaySales: number;
  weekSales: number;
  monthSales: number;
  totalOrders: number;
  pendingOrders: number;
  shippedOrders: number;
  cancelledOrders: number;
  totalCustomers: number;
  totalProducts: number;
  lowStockProducts: number;
  totalRevenue: number;
  averageOrderValue: number;
}

const DashboardKPIs = () => {
  const [kpiData, setKpiData] = useState<KPIData>({
    todaySales: 0,
    weekSales: 0,
    monthSales: 0,
    totalOrders: 0,
    pendingOrders: 0,
    shippedOrders: 0,
    cancelledOrders: 0,
    totalCustomers: 0,
    totalProducts: 0,
    lowStockProducts: 0,
    totalRevenue: 0,
    averageOrderValue: 0
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchKPIData();
  }, []);

  const fetchKPIData = async () => {
    try {
      setIsLoading(true);
      
      const today = new Date();
      const weekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
      const monthAgo = new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000);
      
      // Format dates for SQL
      const formatDate = (date: Date) => date.toISOString().split('T')[0];
      
      // Fetch all orders
      const { data: orders } = await supabase
        .from('orders')
        .select('total_amount, status, created_at');

      // Fetch products with stock info
      const { data: products } = await supabase
        .from('products')
        .select('stock_quantity, status');

      // Fetch customer count
      const { count: customersCount } = await supabase
        .from('profiles')
        .select('*', { count: 'exact', head: true })
        .eq('role', 'customer');

      if (orders && products) {
        const now = new Date();
        const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        
        // Calculate sales by period
        const todaySales = orders
          .filter(order => new Date(order.created_at) >= todayStart)
          .reduce((sum, order) => sum + Number(order.total_amount), 0);
        
        const weekSales = orders
          .filter(order => new Date(order.created_at) >= weekAgo)
          .reduce((sum, order) => sum + Number(order.total_amount), 0);
        
        const monthSales = orders
          .filter(order => new Date(order.created_at) >= monthAgo)
          .reduce((sum, order) => sum + Number(order.total_amount), 0);

        // Calculate order statistics
        const orderStats = orders.reduce((acc, order) => {
          acc.total++;
          if (order.status === 'pending') acc.pending++;
          if (order.status === 'shipped') acc.shipped++;
          if (order.status === 'cancelled') acc.cancelled++;
          return acc;
        }, { total: 0, pending: 0, shipped: 0, cancelled: 0 });

        // Calculate product statistics
        const activeProducts = products.filter(p => p.status === 'active');
        const lowStockProducts = activeProducts.filter(p => p.stock_quantity <= 10);

        // Calculate revenue metrics
        const totalRevenue = orders.reduce((sum, order) => sum + Number(order.total_amount), 0);
        const averageOrderValue = orders.length > 0 ? totalRevenue / orders.length : 0;

        setKpiData({
          todaySales,
          weekSales,
          monthSales,
          totalOrders: orderStats.total,
          pendingOrders: orderStats.pending,
          shippedOrders: orderStats.shipped,
          cancelledOrders: orderStats.cancelled,
          totalCustomers: customersCount || 0,
          totalProducts: activeProducts.length,
          lowStockProducts: lowStockProducts.length,
          totalRevenue,
          averageOrderValue
        });
      }
    } catch (error) {
      console.error('Error fetching KPI data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[...Array(8)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6">
              <div className="h-16 bg-muted rounded"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Revenue & Sales KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-gradient-to-br from-pet-primary/10 to-pet-primary/5 border-pet-primary/20">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-pet-primary">Today's Sales</CardTitle>
            <DollarSign className="h-4 w-4 text-pet-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-pet-primary">₹{kpiData.todaySales.toFixed(2)}</div>
            <p className="text-xs text-pet-neutral mt-1">Sales for today</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">7-Day Sales</CardTitle>
            <Calendar className="h-4 w-4 text-pet-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₹{kpiData.weekSales.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground mt-1">Past 7 days</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">30-Day Sales</CardTitle>
            <TrendingUp className="h-4 w-4 text-pet-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₹{kpiData.monthSales.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground mt-1">Past 30 days</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Order Value</CardTitle>
            <ArrowUpDown className="h-4 w-4 text-pet-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₹{kpiData.averageOrderValue.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground mt-1">Per order average</p>
          </CardContent>
        </Card>
      </div>

      {/* Orders & Inventory KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Orders</CardTitle>
            <ShoppingCart className="h-4 w-4 text-pet-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{kpiData.totalOrders}</div>
            <div className="flex gap-2 mt-2">
              <Badge variant="secondary" className="text-xs">
                {kpiData.pendingOrders} Pending
              </Badge>
              <Badge variant="outline" className="text-xs">
                {kpiData.shippedOrders} Shipped
              </Badge>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Customers</CardTitle>
            <Users className="h-4 w-4 text-pet-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{kpiData.totalCustomers}</div>
            <p className="text-xs text-muted-foreground mt-1">Registered customers</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Products</CardTitle>
            <Package className="h-4 w-4 text-pet-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{kpiData.totalProducts}</div>
            <p className="text-xs text-muted-foreground mt-1">Active products</p>
          </CardContent>
        </Card>

        <Card className={kpiData.lowStockProducts > 0 ? "bg-destructive/10 border-destructive/20" : ""}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Low Stock Alert</CardTitle>
            <AlertTriangle className={`h-4 w-4 ${kpiData.lowStockProducts > 0 ? 'text-destructive' : 'text-pet-primary'}`} />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${kpiData.lowStockProducts > 0 ? 'text-destructive' : ''}`}>
              {kpiData.lowStockProducts}
            </div>
            <p className="text-xs text-muted-foreground mt-1">Products ≤ 10 stock</p>
          </CardContent>
        </Card>
      </div>

      {/* Total Revenue Summary */}
      <Card className="bg-gradient-to-r from-pet-accent to-pet-warm">
        <CardHeader>
          <CardTitle className="text-pet-primary">Revenue Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold text-pet-primary">
            ₹{kpiData.totalRevenue.toFixed(2)}
          </div>
          <p className="text-pet-neutral mt-1">Total revenue from all orders</p>
        </CardContent>
      </Card>
    </div>
  );
};

export default DashboardKPIs;