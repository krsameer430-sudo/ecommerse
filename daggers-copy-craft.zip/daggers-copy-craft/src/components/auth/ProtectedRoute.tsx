import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Skeleton } from '@/components/ui/skeleton';

interface ProtectedRouteProps {
  children: React.ReactNode;
  requiredRole?: 'admin' | 'customer';
  requireAuth?: boolean;
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ 
  children, 
  requiredRole,
  requireAuth = true 
}) => {
  const { user, userProfile, isLoading, hasRole } = useAuth();
  const location = useLocation();

  // Show loading state while checking authentication
  if (isLoading) {
    return (
      <div className="min-h-screen bg-pet-soft flex items-center justify-center p-4">
        <div className="space-y-4 w-full max-w-md">
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-32 w-full" />
          <Skeleton className="h-8 w-3/4" />
        </div>
      </div>
    );
  }

  // If authentication is required but user is not logged in
  if (requireAuth && !user) {
    return <Navigate to="/auth" state={{ from: location }} replace />;
  }

  // If specific role is required but user doesn't have it
  if (requiredRole && !hasRole(requiredRole)) {
    // Redirect admin to dashboard, customer to shop
    const redirectTo = userProfile?.role === 'admin' ? '/dashboard' : '/shop';
    return <Navigate to={redirectTo} replace />;
  }

  // If user is authenticated but no profile exists (shouldn't happen with trigger)
  if (requireAuth && user && !userProfile) {
    return (
      <div className="min-h-screen bg-pet-soft flex items-center justify-center p-4">
        <div className="text-center space-y-4">
          <h2 className="text-xl font-semibold text-pet-primary">Setting up your account...</h2>
          <p className="text-pet-neutral">Please wait while we complete your profile setup.</p>
          <Skeleton className="h-8 w-48 mx-auto" />
        </div>
      </div>
    );
  }

  return <>{children}</>;
};

export default ProtectedRoute;