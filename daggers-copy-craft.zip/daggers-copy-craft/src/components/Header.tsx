import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";
import { useCart } from "@/contexts/CartContext";
import { Link } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import { useSessionManager } from "@/hooks/useSessionManager";
import { ShoppingCart } from "lucide-react";

const Header = () => {
  const { user, userProfile, signOut, isAdmin, isCustomer } = useAuth();
  const { getTotalItems } = useCart();
  useSessionManager(); // Monitor session status

  return (
    <header className="bg-background/80 backdrop-blur-sm border-b border-border sticky top-0 z-50">
      <div className="container mx-auto px-4 py-3 lg:py-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center space-x-1 sm:space-x-2">
            <h1 className="text-xl sm:text-2xl font-bold text-pet-primary">DAGGERS</h1>
            <span className="hidden sm:inline text-sm text-pet-neutral">Premium Pet Essentials</span>
          </Link>
          
          <nav className="hidden lg:flex items-center space-x-8">
            <Link to="/shop" className="text-foreground hover:text-pet-primary transition-colors">Shop All</Link>
            <Link to="/shop" className="text-foreground hover:text-pet-primary transition-colors">Dogs</Link>
            <Link to="/shop" className="text-foreground hover:text-pet-primary transition-colors">Cats</Link>
            <a href="#" className="text-foreground hover:text-pet-primary transition-colors">About</a>
          </nav>
          
          <div className="flex items-center space-x-2 sm:space-x-4">
            {user ? (
              <div className="flex items-center space-x-2 sm:space-x-4">
                <Link to="/cart" className="hidden sm:block">
                  <Button variant="outline" size="sm" className="flex items-center gap-2">
                    <ShoppingCart className="w-4 h-4" />
                    <span className="hidden md:inline">Cart</span>
                    ({getTotalItems()})
                  </Button>
                </Link>
                <Link to="/shop" className="hidden sm:block">
                  <Button variant="outline" size="sm">Shop</Button>
                </Link>
                {userProfile?.role === 'admin' && (
                  <Link to="/dashboard">
                    <Button variant="outline" size="sm" className="text-xs sm:text-sm">
                      <Badge variant="secondary" className="mr-1 sm:mr-2 text-xs">Admin</Badge>
                      <span className="hidden sm:inline">Dashboard</span>
                      <span className="sm:hidden">Admin</span>
                    </Button>
                  </Link>
                )}
                <span className="hidden md:inline text-sm text-pet-neutral truncate max-w-24 lg:max-w-none">
                  Hello, {userProfile?.full_name || user.email?.split('@')[0]}
                </span>
                <Button variant="outline" size="sm" onClick={signOut} className="text-xs sm:text-sm">
                  <span className="hidden sm:inline">Sign Out</span>
                  <span className="sm:hidden">Out</span>
                </Button>
              </div>
            ) : (
              <div className="flex items-center space-x-2 sm:space-x-4">
                <Link to="/cart" className="hidden sm:block">
                  <Button variant="outline" size="sm" className="flex items-center gap-2">
                    <ShoppingCart className="w-4 h-4" />
                    <span className="hidden md:inline">Cart</span>
                    ({getTotalItems()})
                  </Button>
                </Link>
                <Link to="/shop" className="hidden sm:block">
                  <Button variant="outline" size="sm">Shop</Button>
                </Link>
                <Link to="/auth">
                  <Button variant="warm" size="sm" className="text-xs sm:text-sm">
                    <span className="hidden sm:inline">Sign In</span>
                    <span className="sm:hidden">Login</span>
                  </Button>
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;