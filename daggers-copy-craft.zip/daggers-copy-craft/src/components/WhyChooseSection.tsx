import { Shield, Heart, Star, Award } from "lucide-react";

const WhyChooseSection = () => {
  const features = [
    {
      icon: <Shield className="w-8 h-8 text-pet-primary" />,
      title: "Premium Quality Materials",
      description: "Crafted with the finest, pet-safe materials ensuring maximum durability and long-lasting comfort for your beloved companions."
    },
    {
      icon: <Heart className="w-8 h-8 text-pet-primary" />,
      title: "Comfort-First Design",
      description: "Every product prioritizes your pet's comfort with ultra-soft, breathable fabrics and ergonomic fits that move naturally with your pet."
    },
    {
      icon: <Star className="w-8 h-8 text-pet-primary" />,
      title: "Fashion-Forward Style",
      description: "Trendy, Instagram-worthy designs that make your pets the center of attention while maintaining functionality and comfort."
    },
    {
      icon: <Award className="w-8 h-8 text-pet-primary" />,
      title: "Trusted by Pet Parents",
      description: "Join thousands of satisfied pet parents across India who trust DAGGERS for premium quality and exceptional customer care."
    }
  ];

  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-foreground mb-4">
            Why Choose DAGGERS?
          </h2>
          <p className="text-xl text-pet-neutral max-w-2xl mx-auto">
            Crafted for Care & Comfort • Trusted by 10,000+ Happy Pet Parents
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="text-center p-6 rounded-xl bg-pet-warm hover:shadow-lg transition-all duration-300">
              <div className="flex justify-center mb-4">
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-3">
                {feature.title}
              </h3>
              <p className="text-pet-neutral leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
        
        <div className="text-center mt-16">
          <div className="inline-flex items-center space-x-4 bg-pet-accent rounded-full px-8 py-4">
            <Star className="w-6 h-6 text-pet-primary fill-current" />
            <span className="text-lg font-semibold text-pet-primary">
              4.9/5 Rating • 10,000+ Happy Pet Parents • Premium Quality Guaranteed
            </span>
            <Star className="w-6 h-6 text-pet-primary fill-current" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default WhyChooseSection;