import { Button } from "@/components/ui/button";
import { Heart, Mail, Phone, MapPin } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-foreground text-background">
      <div className="container mx-auto px-4 py-16">
        <div className="grid md:grid-cols-4 gap-8 mb-12">
          <div className="space-y-4">
            <h3 className="text-2xl font-bold text-pet-accent">DAGGERS</h3>
            <p className="text-background/80">
              Premium pet accessories crafted with love for pets who deserve the best.
            </p>
            <div className="flex items-center space-x-2 text-pet-accent">
              <Heart className="w-4 h-4 fill-current" />
              <span className="text-sm">Made with love for pets</span>
            </div>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4 text-pet-accent">Quick Links</h4>
            <ul className="space-y-2 text-background/80">
              <li><a href="#" className="hover:text-pet-accent transition-colors">Shop Dogs</a></li>
              <li><a href="#" className="hover:text-pet-accent transition-colors">Shop Cats</a></li>
              <li><a href="#" className="hover:text-pet-accent transition-colors">New Arrivals</a></li>
              <li><a href="#" className="hover:text-pet-accent transition-colors">Sale</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4 text-pet-accent">Categories</h4>
            <ul className="space-y-2 text-background/80">
              <li><a href="#" className="hover:text-pet-accent transition-colors">Jackets</a></li>
              <li><a href="#" className="hover:text-pet-accent transition-colors">Shoes</a></li>
              <li><a href="#" className="hover:text-pet-accent transition-colors">Harnesses</a></li>
              <li><a href="#" className="hover:text-pet-accent transition-colors">Raincoats</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4 text-pet-accent">Contact Us</h4>
            <ul className="space-y-3 text-background/80">
              <li className="flex items-center space-x-2">
                <Mail className="w-4 h-4" />
                <span>support@daggers.in</span>
              </li>
              <li className="flex items-center space-x-2">
                <Phone className="w-4 h-4" />
                <span>+91 12345 67890</span>
              </li>
              <li className="flex items-center space-x-2">
                <MapPin className="w-4 h-4" />
                <span>Mumbai, India</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-background/20 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <p className="text-background/60 text-sm">
              © 2024 DAGGERS. All rights reserved. | Privacy Policy | Terms of Service
            </p>
            <div className="flex space-x-4">
              <Button variant="outline" size="sm" className="border-pet-accent text-pet-accent hover:bg-pet-accent hover:text-foreground">
                Instagram
              </Button>
              <Button variant="outline" size="sm" className="border-pet-accent text-pet-accent hover:bg-pet-accent hover:text-foreground">
                Facebook
              </Button>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;