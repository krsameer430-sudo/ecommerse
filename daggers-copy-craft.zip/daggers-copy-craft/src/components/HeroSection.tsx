import { Button } from "@/components/ui/button";
import heroImage from "@/assets/hero-pets.jpg";

const HeroSection = () => {
  return (
    <section className="relative min-h-screen flex items-center bg-gradient-to-br from-pet-warm to-pet-accent">
      <div className="container mx-auto px-4 py-12 lg:py-20">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
          <div className="space-y-6 lg:space-y-8 text-center lg:text-left">
            <h1 className="text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-bold text-foreground leading-tight">
              Premium Pet Lifestyle & 
              <span className="text-pet-primary"> Comfort</span>
            </h1>
            
            <p className="text-base sm:text-lg lg:text-xl text-pet-neutral leading-relaxed max-w-2xl mx-auto lg:mx-0">
              DAGGERS crafts stylish, comfortable, and durable pet essentials for dogs and cats who deserve the very best. From premium jackets and protective shoes to secure harnesses and waterproof raincoats - every piece is designed with love, care, and attention to detail.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button variant="hero" size="lg" className="text-base sm:text-lg px-6 sm:px-8 py-4 sm:py-6">
                Shop Now
              </Button>
              <Button variant="outline" size="lg" className="text-base sm:text-lg px-6 sm:px-8 py-4 sm:py-6">
                Explore Collection
              </Button>
            </div>
            
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 sm:gap-8 text-sm text-pet-neutral">
              <div className="flex items-center space-x-2">
                <span className="w-2 h-2 bg-pet-primary rounded-full"></span>
                <span>Free Shipping Over ₹999</span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="w-2 h-2 bg-pet-primary rounded-full"></span>
                <span>30-Day Returns</span>
              </div>
            </div>
          </div>
          
          <div className="relative mt-8 lg:mt-0">
            <img 
              src={heroImage} 
              alt="Happy pets wearing DAGGERS premium accessories" 
              className="rounded-2xl shadow-2xl w-full h-auto max-w-lg mx-auto"
            />
            <div className="absolute -bottom-4 sm:-bottom-6 -right-4 sm:-right-6 bg-white rounded-xl p-3 sm:p-4 shadow-lg">
              <p className="text-xs sm:text-sm font-semibold text-pet-primary">Trusted by 10,000+ Pet Parents</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;