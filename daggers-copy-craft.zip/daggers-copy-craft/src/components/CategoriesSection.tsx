import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import dogJacket from "@/assets/dog-jacket.jpg";
import catHarness from "@/assets/cat-harness.jpg";
import productsCollection from "@/assets/products-collection.jpg";

const CategoriesSection = () => {
  const navigate = useNavigate();
  
  const categories = [
    {
      name: "Premium Dog & Cat Jackets",
      description: "Ultra-cozy warmth for every season. Our premium winter jackets and fashion-forward outerwear keep your pets comfortable while turning heads on every walk.",
      image: dogJacket,
      keywords: "dog jackets, cat jackets, pet winter wear, premium pet clothing"
    },
    {
      name: "Protective Dog & Cat Shoes",
      description: "Advanced paw protection meets style. Our durable, non-slip shoes protect against hot pavement, sharp objects, and harsh weather conditions.",
      image: productsCollection,
      keywords: "dog shoes, cat shoes, paw protection, pet footwear"
    },
    {
      name: "Secure Dog & Cat Harnesses",
      description: "Ultimate safety meets comfort. Our ergonomic harnesses distribute pressure evenly, ensuring secure walks while preventing neck strain and injury.",
      image: catHarness,
      keywords: "dog harness, cat harness, pet safety, walking accessories"
    },
    {
      name: "Healing Dog & Cat Bandages",
      description: "Professional-grade recovery support. Our therapeutic bandages and protective wear accelerate healing while keeping your pet comfortable during recovery.",
      image: productsCollection,
      keywords: "pet bandages, recovery wear, therapeutic pet accessories"
    },
    {
      name: "Waterproof Dog & Cat Raincoats",
      description: "100% waterproof protection with breathable comfort. Our stylish raincoats keep your pets dry and happy during monsoon adventures.",
      image: dogJacket,
      keywords: "dog raincoats, cat raincoats, waterproof pet wear, monsoon protection"
    }
  ];

  return (
    <section className="py-20 bg-pet-warm">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-foreground mb-4">
            Featured Categories
          </h2>
          <p className="text-xl text-pet-neutral max-w-3xl mx-auto">
            Keep your furry friend safe, stylish, and happy with our carefully curated collection of premium pet accessories.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {categories.map((category, index) => (
            <div key={index} className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 group">
              <div className="aspect-square overflow-hidden">
                <img 
                  src={category.image} 
                  alt={category.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold text-foreground mb-3">
                  {category.name}
                </h3>
                <p className="text-pet-neutral mb-4 leading-relaxed">
                  {category.description}
                </p>
                <Button 
                  variant="warm" 
                  className="w-full"
                  onClick={() => navigate('/shop')}
                >
                  Shop {category.name.split(' ')[2]}
                </Button>
              </div>
            </div>
          ))}
        </div>
        
        <div className="text-center">
          <p className="text-2xl font-semibold text-pet-primary mb-6">
            "Because your pet deserves the best"
          </p>
          <Button 
            variant="hero" 
            size="lg" 
            className="text-lg px-12 py-6"
            onClick={() => navigate('/shop')}
          >
            View All Categories
          </Button>
        </div>
      </div>
    </section>
  );
};

export default CategoriesSection;