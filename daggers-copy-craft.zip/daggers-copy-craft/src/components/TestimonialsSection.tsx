import { Star, Quote } from "lucide-react";

const TestimonialsSection = () => {
  const testimonials = [
    {
      name: "Priya Sharma",
      pet: "Golden Retriever - Max",
      rating: 5,
      comment: "Absolutely love DAGGERS! Max's premium jacket fits like a glove and the quality is outstanding. He gets so many compliments! The material is incredibly soft yet durable. Best investment for my furry baby!"
    },
    {
      name: "Rajesh Patel",
      pet: "Persian Cat - Whiskers",
      rating: 5,
      comment: "After trying multiple brands, DAGGERS harness is the only one Whiskers doesn't try to escape from! The comfort-first design is evident and the style is unmatched. Exceptional customer service too!"
    },
    {
      name: "Anita Reddy",
      pet: "Labrador - Buddy",
      rating: 5,
      comment: "Buddy's DAGGERS raincoat is a lifesaver during Mumbai monsoons! 100% waterproof, breathable, and he actually enjoys wearing it. Premium quality that's worth every rupee. Highly recommended!"
    }
  ];

  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-foreground mb-4">
            Customer Love
          </h2>
          <p className="text-xl text-pet-neutral">
            What pet parents are saying about DAGGERS
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-pet-warm p-8 rounded-2xl shadow-lg relative">
              <Quote className="w-8 h-8 text-pet-primary absolute top-6 right-6 opacity-50" />
              
              <div className="flex items-center mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-pet-primary fill-current" />
                ))}
              </div>
              
              <p className="text-pet-neutral mb-6 leading-relaxed italic">
                "{testimonial.comment}"
              </p>
              
              <div>
                <p className="font-semibold text-foreground">{testimonial.name}</p>
                <p className="text-sm text-pet-neutral">Pet Parent to {testimonial.pet}</p>
              </div>
            </div>
          ))}
        </div>
        
        <div className="text-center mt-16">
          <div className="bg-gradient-to-r from-pet-primary to-pet-primary-light rounded-2xl p-8 text-white">
            <h3 className="text-2xl font-bold mb-4">Ready to Spoil Your Pet?</h3>
            <p className="text-lg mb-6 opacity-90">
              Join 10,000+ happy pet parents who trust DAGGERS for premium quality, style, and comfort
            </p>
            <div className="flex justify-center items-center space-x-2">
              <span className="text-3xl font-bold">4.9</span>
              <div className="flex">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-6 h-6 fill-current" />
                ))}
              </div>
              <span className="text-lg opacity-90">Average Rating</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;