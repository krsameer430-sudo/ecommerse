import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useCart } from "@/contexts/CartContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Plus, Minus, Trash2, ArrowLeft, ShoppingBag } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const Cart = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { cartItems, updateQuantity, removeFromCart, getTotalPrice, isLoading } = useCart();

  const calculateTax = () => {
    return getTotalPrice() * 0.18; // 18% GST
  };

  const calculateShipping = () => {
    const subtotal = getTotalPrice();
    return subtotal > 999 ? 0 : 99; // Free shipping above ₹999
  };

  if (isLoading) {
    return <div className="flex items-center justify-center min-h-screen">Loading...</div>;
  }

  return (
    <main className="min-h-screen bg-background">
      <Header />
      
      <div className="container mx-auto py-8">
        <div className="mb-6">
          <Button 
            variant="ghost" 
            onClick={() => navigate('/shop')}
            className="mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Continue Shopping
          </Button>
          <h1 className="text-3xl font-bold text-foreground">Shopping Cart</h1>
        </div>

        {cartItems.length === 0 ? (
          <div className="text-center py-16">
            <ShoppingBag className="w-24 h-24 mx-auto mb-6 text-muted-foreground" />
            <h2 className="text-2xl font-semibold mb-4">Your cart is empty</h2>
            <p className="text-muted-foreground mb-8">
              Looks like you haven't added any items to your cart yet.
            </p>
            <Button onClick={() => navigate('/shop')} size="lg">
              Start Shopping
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Cart Items */}
            <div className="lg:col-span-2 space-y-4">
              {cartItems.map((item) => (
                <div key={item.id || item.product_id} className="flex items-center gap-4 p-4 border rounded-lg">
                  <div className="w-20 h-20 bg-muted rounded overflow-hidden flex-shrink-0">
                    {item.product?.image_url ? (
                      <img
                        src={item.product.image_url}
                        alt={item.product.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-muted-foreground text-xs">
                        No image
                      </div>
                    )}
                  </div>
                  
                  <div className="flex-1">
                    <h3 className="font-semibold">{item.product?.name}</h3>
                    <div className="flex items-center gap-2 mt-2">
                      {item.product?.sale_price ? (
                        <>
                          <span className="font-bold text-primary">₹{item.product.sale_price}</span>
                          <span className="text-sm text-muted-foreground line-through">₹{item.product.price}</span>
                        </>
                      ) : (
                        <span className="font-bold text-primary">₹{item.product?.price}</span>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => updateQuantity(item.product_id, item.quantity - 1)}
                        disabled={isLoading}
                      >
                        <Minus className="w-4 h-4" />
                      </Button>
                      <span className="w-8 text-center font-medium">{item.quantity}</span>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => updateQuantity(item.product_id, item.quantity + 1)}
                        disabled={isLoading || item.quantity >= (item.product?.stock_quantity || 0)}
                      >
                        <Plus className="w-4 h-4" />
                      </Button>
                    </div>
                    
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => removeFromCart(item.product_id)}
                      disabled={isLoading}
                      className="text-destructive hover:text-destructive hover:bg-destructive/10"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                  
                  <div className="text-right">
                    <p className="font-semibold">
                      ₹{((item.product?.sale_price || item.product?.price || 0) * item.quantity).toFixed(2)}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {/* Order Summary */}
            <div className="lg:col-span-1">
              <Card className="sticky top-8">
                <CardHeader>
                  <CardTitle>Order Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center text-base">
                    <span>Subtotal</span>
                    <span>₹{getTotalPrice().toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between items-center text-base">
                    <span>Tax (GST 18%)</span>
                    <span>₹{calculateTax().toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between items-center text-base">
                    <span>Shipping</span>
                    <span>{calculateShipping() === 0 ? 'Free' : `₹${calculateShipping()}`}</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between items-center text-lg font-bold border-t pt-4">
                    <span>Total</span>
                    <span>₹{(getTotalPrice() + calculateTax() + calculateShipping()).toFixed(2)}</span>
                  </div>
                  
                  <Button 
                    className="w-full" 
                    size="lg"
                    onClick={() => {
                      if (!user) {
                        navigate('/auth', { state: { from: '/checkout' } });
                      } else {
                        navigate('/checkout');
                      }
                    }}
                    disabled={cartItems.length === 0}
                  >
                    Proceed to Checkout
                  </Button>

                  {getTotalPrice() < 999 && (
                    <p className="text-sm text-muted-foreground text-center">
                      Add ₹{(999 - getTotalPrice()).toFixed(2)} more for free shipping!
                    </p>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </div>

      <Footer />
    </main>
  );
};

export default Cart;