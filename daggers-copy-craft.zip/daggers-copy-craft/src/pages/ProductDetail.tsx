import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ShoppingCart, Plus, Minus, ArrowLeft, Star } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  sale_price: number | null;
  stock_quantity: number;
  category_id: string;
  image_url: string | null;
  images: string[] | null;
  categories?: { name: string };
}

interface CartItem {
  id: string;
  product_id: string;
  quantity: number;
}

const ProductDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [product, setProduct] = useState<Product | null>(null);
  const [cartQuantity, setCartQuantity] = useState(0);
  const [selectedImage, setSelectedImage] = useState(0);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (id) {
      fetchProduct();
      if (user) {
        fetchCartQuantity();
      }
    }
  }, [id, user]);

  const fetchProduct = async () => {
    if (!id) return;
    
    try {
      const { data, error } = await supabase
        .from('products')
        .select(`
          *,
          categories(name)
        `)
        .eq('id', id)
        .eq('status', 'active')
        .single();

      if (error) throw error;
      setProduct(data);
    } catch (error) {
      console.error('Error fetching product:', error);
      toast({
        title: "Error",
        description: "Product not found",
        variant: "destructive",
      });
      navigate('/shop');
    } finally {
      setIsLoading(false);
    }
  };

  const fetchCartQuantity = async () => {
    if (!user || !id) return;

    try {
      const { data, error } = await supabase
        .from('cart_items')
        .select('quantity')
        .eq('user_id', user.id)
        .eq('product_id', id)
        .maybeSingle();

      if (error) throw error;
      setCartQuantity(data?.quantity || 0);
    } catch (error) {
      console.error('Error fetching cart quantity:', error);
    }
  };

  const addToCart = async () => {
    if (!user || !product) {
      toast({
        title: "Login Required",
        description: "Please sign in to add items to your cart",
        variant: "destructive",
      });
      navigate('/auth');
      return;
    }

    try {
      if (cartQuantity > 0) {
        const { error } = await supabase
          .from('cart_items')
          .update({ quantity: cartQuantity + 1 })
          .eq('user_id', user.id)
          .eq('product_id', product.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('cart_items')
          .insert({
            user_id: user.id,
            product_id: product.id,
            quantity: 1
          });

        if (error) throw error;
      }

      setCartQuantity(prev => prev + 1);
      toast({
        title: "Added to Cart",
        description: "Product added to your cart successfully",
      });
    } catch (error) {
      console.error('Error adding to cart:', error);
      toast({
        title: "Error",
        description: "Failed to add product to cart",
        variant: "destructive",
      });
    }
  };

  const updateQuantity = async (newQuantity: number) => {
    if (!user || !product) return;

    if (newQuantity <= 0) {
      try {
        const { error } = await supabase
          .from('cart_items')
          .delete()
          .eq('user_id', user.id)
          .eq('product_id', product.id);

        if (error) throw error;
        setCartQuantity(0);
        toast({
          title: "Removed from Cart",
          description: "Product removed from your cart",
        });
      } catch (error) {
        console.error('Error removing from cart:', error);
      }
      return;
    }

    try {
      const { error } = await supabase
        .from('cart_items')
        .update({ quantity: newQuantity })
        .eq('user_id', user.id)
        .eq('product_id', product.id);

      if (error) throw error;
      setCartQuantity(newQuantity);
    } catch (error) {
      console.error('Error updating cart:', error);
    }
  };

  const productImages = product?.images || (product?.image_url ? [product.image_url] : []);
  const currentPrice = product?.sale_price || product?.price;
  const originalPrice = product?.sale_price ? product.price : null;

  if (isLoading) {
    return <div className="flex items-center justify-center min-h-screen">Loading...</div>;
  }

  if (!product) {
    return <div className="flex items-center justify-center min-h-screen">Product not found</div>;
  }

  return (
    <main className="min-h-screen bg-background">
      <Header />
      
      <div className="container mx-auto py-8">
        <Button
          variant="ghost"
          onClick={() => navigate('/shop')}
          className="mb-6"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Shop
        </Button>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Product Images */}
          <div className="space-y-4">
            <div className="aspect-square bg-muted rounded-lg overflow-hidden">
              {productImages.length > 0 ? (
                <img
                  src={productImages[selectedImage]}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-muted-foreground">
                  No image available
                </div>
              )}
            </div>
            
            {productImages.length > 1 && (
              <div className="flex gap-2 overflow-x-auto">
                {productImages.map((image, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedImage(index)}
                    className={`w-20 h-20 rounded-lg overflow-hidden border-2 flex-shrink-0 ${
                      selectedImage === index ? 'border-primary' : 'border-border'
                    }`}
                  >
                    <img
                      src={image}
                      alt={`${product.name} ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Badge variant="outline">
                  {product.categories?.name}
                </Badge>
                {product.stock_quantity <= 5 && (
                  <Badge variant="destructive">
                    Low Stock
                  </Badge>
                )}
              </div>
              <h1 className="text-3xl font-bold mb-4">{product.name}</h1>
              
              <div className="flex items-center gap-3 mb-4">
                {originalPrice && (
                  <span className="text-2xl text-muted-foreground line-through">
                    ₹{originalPrice}
                  </span>
                )}
                <span className="text-3xl font-bold text-primary">
                  ₹{currentPrice}
                </span>
                {originalPrice && (
                  <Badge variant="secondary" className="ml-2">
                    {Math.round(((originalPrice - currentPrice!) / originalPrice) * 100)}% OFF
                  </Badge>
                )}
              </div>

              <div className="flex items-center gap-2 mb-4">
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <span className="text-sm text-muted-foreground">(4.8) • 234 reviews</span>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">Description</h3>
                <p className="text-muted-foreground leading-relaxed">
                  {product.description}
                </p>
              </div>

              <div>
                <span className="font-semibold">Stock: </span>
                <span className={product.stock_quantity > 10 ? 'text-green-600' : 'text-orange-600'}>
                  {product.stock_quantity} available
                </span>
              </div>
            </div>

            {/* Add to Cart Actions */}
            <Card className="p-4">
              <CardContent className="p-0">
                {user ? (
                  product.stock_quantity === 0 ? (
                    <Button disabled className="w-full">
                      Out of Stock
                    </Button>
                  ) : cartQuantity > 0 ? (
                    <div className="space-y-3">
                      <div className="flex items-center justify-center gap-4">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => updateQuantity(cartQuantity - 1)}
                        >
                          <Minus className="w-4 h-4" />
                        </Button>
                        <span className="text-xl font-semibold">{cartQuantity}</span>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => updateQuantity(cartQuantity + 1)}
                          disabled={cartQuantity >= product.stock_quantity}
                        >
                          <Plus className="w-4 h-4" />
                        </Button>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          className="flex-1"
                          onClick={() => updateQuantity(0)}
                        >
                          Remove from Cart
                        </Button>
                        <Button
                          className="flex-1"
                          onClick={() => navigate('/cart')}
                        >
                          Go to Cart
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <Button
                      className="w-full"
                      onClick={addToCart}
                      size="lg"
                    >
                      <ShoppingCart className="w-5 h-5 mr-2" />
                      Add to Cart - ₹{currentPrice}
                    </Button>
                  )
                ) : (
                  <Button
                    className="w-full"
                    onClick={() => navigate('/auth')}
                    size="lg"
                  >
                    Sign In to Purchase
                  </Button>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <Footer />
    </main>
  );
};

export default ProductDetail;