import { useEffect } from "react";
import Header from "@/components/Header";
import HeroSection from "@/components/HeroSection";
import WhyChooseSection from "@/components/WhyChooseSection";
import CategoriesSection from "@/components/CategoriesSection";
import TestimonialsSection from "@/components/TestimonialsSection";
import Footer from "@/components/Footer";

const Index = () => {
  useEffect(() => {
    // SEO optimization
    document.title = "DAGGERS - Premium Pet Accessories for Dogs & Cats | Jackets, Shoes, Harnesses";
    
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute("content", "Shop premium pet accessories at DAGGERS. High-quality dog jackets, cat harnesses, pet shoes, raincoats & more. Stylish, comfortable & durable pet essentials. Free shipping over ₹999.");
    }
    
    // Add structured data for SEO
    const structuredData = {
      "@context": "https://schema.org",
      "@type": "PetStore",
      "name": "DAGGERS",
      "description": "Premium pet accessories brand specializing in stylish and comfortable essentials for dogs and cats",
      "url": "https://daggers.in",
      "priceRange": "₹₹",
      "address": {
        "@type": "PostalAddress",
        "addressCountry": "IN"
      }
    };
    
    const script = document.createElement('script');
    script.type = 'application/ld+json';
    script.text = JSON.stringify(structuredData);
    document.head.appendChild(script);
    
    return () => {
      document.head.removeChild(script);
    };
  }, []);

  return (
    <main className="min-h-screen">
      <Header />
      <HeroSection />
      <WhyChooseSection />
      <CategoriesSection />
      <TestimonialsSection />
      <Footer />
    </main>
  );
};

export default Index;
