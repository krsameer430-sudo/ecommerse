import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { InputOTP, InputOTPGroup, InputOTPSlot } from '@/components/ui/input-otp';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';

const Auth = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { signIn, signUp, sendOtp, verifyOtp, user } = useAuth();
  const { toast } = useToast();

  // State for different forms
  const [loginData, setLoginData] = useState({ emailOrPhone: '', password: '' });
  const [signupData, setSignupData] = useState({
    email: '',
    password: '',
    fullName: '',
    phoneNumber: ''
  });

  // OTP flow state
  const [showOtpVerification, setShowOtpVerification] = useState(false);
  const [otpValue, setOtpValue] = useState('');
  const [otpMethod, setOtpMethod] = useState('');
  const [currentEmailOrPhone, setCurrentEmailOrPhone] = useState('');

  // Loading states
  const [isLoading, setIsLoading] = useState(false);

  const from = location.state?.from?.pathname || '/';

  useEffect(() => {
    if (user) {
      navigate(from, { replace: true });
    }
  }, [user, navigate, from]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const result = await sendOtp(loginData.emailOrPhone, loginData.password);
      
      if (result.error) {
        toast({
          variant: "destructive",
          title: "Login Failed",
          description: result.error.message || "Invalid credentials. Please try again.",
        });
      } else {
        // OTP sent successfully
        setCurrentEmailOrPhone(loginData.emailOrPhone);
        setOtpMethod(result.method || 'Email');
        setShowOtpVerification(true);
        toast({
          title: "OTP Sent",
          description: `A 6-digit verification code has been sent to your ${result.method || 'email'}.`,
        });
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleOtpVerification = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (otpValue.length !== 6) {
      toast({
        variant: "destructive",
        title: "Invalid OTP",
        description: "Please enter a complete 6-digit OTP.",
      });
      return;
    }

    setIsLoading(true);

    try {
      const result = await verifyOtp(currentEmailOrPhone, otpValue);
      
      if (result.error) {
        toast({
          variant: "destructive",
          title: "Verification Failed",
          description: result.error.message || "Invalid or expired OTP. Please try again.",
        });
        setOtpValue('');
      } else {
        toast({
          title: "Login Successful",
          description: "You have been successfully logged in.",
        });
        // Navigation will be handled by the useEffect when user state updates
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
      });
      setOtpValue('');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const result = await signUp(
        signupData.email,
        signupData.password,
        signupData.fullName,
        signupData.phoneNumber
      );

      if (result.error) {
        if (result.error.message === 'User already registered') {
          toast({
            variant: "destructive",
            title: "Registration Failed",
            description: "An account with this email already exists. Please try logging in instead.",
          });
        } else {
          toast({
            variant: "destructive",
            title: "Registration Failed",
            description: result.error.message || "Failed to create account. Please try again.",
          });
        }
      } else {
        toast({
          title: "Account Created",
          description: "Your account has been created successfully. Please check your email for verification.",
        });
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleBackToLogin = () => {
    setShowOtpVerification(false);
    setOtpValue('');
    setCurrentEmailOrPhone('');
    setOtpMethod('');
  };

  const handleResendOtp = async () => {
    setIsLoading(true);
    try {
      const result = await sendOtp(currentEmailOrPhone, loginData.password);
      
      if (result.error) {
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to resend OTP. Please try again.",
        });
      } else {
        toast({
          title: "OTP Resent",
          description: `A new verification code has been sent to your ${result.method || 'email'}.`,
        });
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  if (showOtpVerification) {
    return (
      <div className="min-h-screen bg-pet-soft flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl font-bold text-center text-pet-primary">
              Verify OTP
            </CardTitle>
            <CardDescription className="text-center">
              Enter the 6-digit code sent to your {otpMethod.toLowerCase()}
            </CardDescription>
          </CardHeader>
          <form onSubmit={handleOtpVerification}>
            <CardContent className="space-y-4">
              <div className="flex justify-center">
                <InputOTP
                  value={otpValue}
                  onChange={setOtpValue}
                  maxLength={6}
                >
                  <InputOTPGroup>
                    <InputOTPSlot index={0} />
                    <InputOTPSlot index={1} />
                    <InputOTPSlot index={2} />
                    <InputOTPSlot index={3} />
                    <InputOTPSlot index={4} />
                    <InputOTPSlot index={5} />
                  </InputOTPGroup>
                </InputOTP>
              </div>
              <p className="text-sm text-muted-foreground text-center">
                Code sent to: {currentEmailOrPhone}
              </p>
            </CardContent>
            <CardFooter className="flex flex-col space-y-3">
              <Button 
                type="submit" 
                className="w-full" 
                disabled={isLoading || otpValue.length !== 6}
              >
                {isLoading ? 'Verifying...' : 'Verify OTP'}
              </Button>
              <div className="flex justify-between w-full text-sm">
                <Button
                  type="button"
                  variant="link"
                  onClick={handleBackToLogin}
                  className="p-0 h-auto"
                >
                  ← Back to Login
                </Button>
                <Button
                  type="button"
                  variant="link"
                  onClick={handleResendOtp}
                  disabled={isLoading}
                  className="p-0 h-auto"
                >
                  Resend OTP
                </Button>
              </div>
            </CardFooter>
          </form>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-pet-soft flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1">
          <CardTitle className="text-2xl font-bold text-center text-pet-primary">
            DAGGERS
          </CardTitle>
          <CardDescription className="text-center">
            Premium Pet Essentials
          </CardDescription>
        </CardHeader>
        <Tabs defaultValue="signin" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-4">
            <TabsTrigger value="signin">Sign In</TabsTrigger>
            <TabsTrigger value="signup">Sign Up</TabsTrigger>
          </TabsList>
          
          <TabsContent value="signin">
            <form onSubmit={handleLogin}>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="emailOrPhone">Email or Phone Number</Label>
                  <Input
                    id="emailOrPhone"
                    type="text"
                    placeholder="Enter your email or phone number"
                    value={loginData.emailOrPhone}
                    onChange={(e) => setLoginData(prev => ({ ...prev, emailOrPhone: e.target.value }))}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="Enter your password"
                    value={loginData.password}
                    onChange={(e) => setLoginData(prev => ({ ...prev, password: e.target.value }))}
                    required
                  />
                </div>
              </CardContent>
              <CardFooter>
                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? 'Signing In...' : 'Sign In'}
                </Button>
              </CardFooter>
            </form>
          </TabsContent>
          
          <TabsContent value="signup">
            <form onSubmit={handleSignup}>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="fullName">Full Name</Label>
                  <Input
                    id="fullName"
                    type="text"
                    placeholder="Enter your full name"
                    value={signupData.fullName}
                    onChange={(e) => setSignupData(prev => ({ ...prev, fullName: e.target.value }))}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="Enter your email"
                    value={signupData.email}
                    onChange={(e) => setSignupData(prev => ({ ...prev, email: e.target.value }))}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phoneNumber">Phone Number</Label>
                  <Input
                    id="phoneNumber"
                    type="tel"
                    placeholder="Enter your phone number (e.g., +1234567890)"
                    value={signupData.phoneNumber}
                    onChange={(e) => setSignupData(prev => ({ ...prev, phoneNumber: e.target.value }))}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="signupPassword">Password</Label>
                  <Input
                    id="signupPassword"
                    type="password"
                    placeholder="Create a password"
                    value={signupData.password}
                    onChange={(e) => setSignupData(prev => ({ ...prev, password: e.target.value }))}
                    required
                  />
                </div>
              </CardContent>
              <CardFooter>
                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? 'Creating Account...' : 'Create Account'}
                </Button>
              </CardFooter>
            </form>
          </TabsContent>
        </Tabs>
      </Card>
    </div>
  );
};

export default Auth;