import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import ProductsManagement from "@/components/admin/ProductsManagement";
import CategoriesManagement from "@/components/admin/CategoriesManagement";
import EnhancedOrdersManagement from "@/components/admin/EnhancedOrdersManagement";
import CustomersManagement from "@/components/admin/CustomersManagement";
import DashboardKPIs from "@/components/admin/DashboardKPIs";
import RecentOrdersWidget from "@/components/admin/RecentOrdersWidget";

const Dashboard = () => {
  const { userProfile } = useAuth();
  const [activeTab, setActiveTab] = useState("overview");

  return (
    <div className="container mx-auto py-8 space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-pet-primary">Admin Dashboard</h1>
          <p className="text-pet-neutral">Welcome back, {userProfile?.full_name}</p>
        </div>
        <Badge variant="secondary" className="bg-pet-warm text-pet-primary">
          Administrator
        </Badge>
      </div>

      {/* Management Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="orders">Orders</TabsTrigger>
          <TabsTrigger value="customers">Customers</TabsTrigger>
          <TabsTrigger value="products">Products</TabsTrigger>
          <TabsTrigger value="categories">Categories</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview" className="space-y-6">
          <DashboardKPIs />
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <RecentOrdersWidget onViewAllOrders={() => setActiveTab("orders")} />
            <div className="space-y-4">
              {/* Additional overview widgets can be added here */}
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="orders" className="space-y-4">
          <EnhancedOrdersManagement />
        </TabsContent>

        <TabsContent value="customers" className="space-y-4">
          <CustomersManagement />
        </TabsContent>
        
        <TabsContent value="products" className="space-y-4">
          <ProductsManagement />
        </TabsContent>
        
        <TabsContent value="categories" className="space-y-4">
          <CategoriesManagement />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Dashboard;