import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';

interface UserProfile {
  id: string;
  user_id: string;
  full_name: string | null;
  phone_number: string | null;
  role: 'admin' | 'customer';
  avatar_url: string | null;
  is_approved: boolean;
  approved_at: string | null;
  created_at: string;
  updated_at: string;
}

interface AuthContextType {
  user: User | null;
  session: Session | null;
  userProfile: UserProfile | null;
  isLoading: boolean;
  isAdmin: boolean;
  isCustomer: boolean;
  signIn: (emailOrPhone: string, password: string) => Promise<{ error: any }>;
  signUp: (email: string, password: string, fullName: string, phoneNumber: string) => Promise<{ error: any }>;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
  hasRole: (role: 'admin' | 'customer') => boolean;
  sendOtp: (emailOrPhone: string, password: string) => Promise<{ error: any; method?: string }>;
  verifyOtp: (emailOrPhone: string, otp: string) => Promise<{ error: any; user?: any; session?: any }>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Computed values for role checking
  const isAdmin = userProfile?.role === 'admin';
  const isCustomer = userProfile?.role === 'customer';
  
  const hasRole = (role: 'admin' | 'customer') => {
    return userProfile?.role === role;
  };

  const fetchUserProfile = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', userId)
        .single();

      if (error && error.code !== 'PGRST116') {
        console.error('Error fetching profile:', error);
        return;
      }

      setUserProfile(data as UserProfile);
    } catch (error) {
      console.error('Error fetching profile:', error);
    }
  };

  const refreshProfile = async () => {
    if (user) {
      await fetchUserProfile(user.id);
    }
  };

  useEffect(() => {
    // Set up auth state listener
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        setSession(session);
        setUser(session?.user ?? null);

        if (session?.user) {
          // Defer profile fetch to avoid potential deadlock
          setTimeout(() => {
            fetchUserProfile(session.user.id);
          }, 0);
        } else {
          setUserProfile(null);
        }

        setIsLoading(false);
      }
    );

    // Check for existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      
      if (session?.user) {
        fetchUserProfile(session.user.id);
      }
      
      setIsLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  const signIn = async (emailOrPhone: string, password: string) => {
    // This is now just a wrapper, actual logic moved to sendOtp
    return await sendOtp(emailOrPhone, password);
  };

  const sendOtp = async (emailOrPhone: string, password: string) => {
    try {
      const response = await supabase.functions.invoke('send-otp', {
        body: { emailOrPhone, password }
      });

      if (response.error) {
        return { error: response.error };
      }

      return { error: null, method: response.data?.method };
    } catch (error) {
      return { error: { message: 'An unexpected error occurred. Please try again.' } };
    }
  };

  const signUp = async (email: string, password: string, fullName: string, phoneNumber: string) => {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          full_name: fullName,
          phone_number: phoneNumber,
        },
      },
    });
    
    if (error && error.message.includes('already registered')) {
      return { error: { message: 'User already registered' } };
    }
    
    return { error };
  };

  const verifyOtp = async (emailOrPhone: string, otp: string) => {
    try {
      const response = await supabase.functions.invoke('verify-otp', {
        body: { emailOrPhone, otp }
      });

      if (response.error) {
        return { error: response.error };
      }

      if (response.data?.success) {
        // Handle successful OTP verification
        // The session will be handled by the auth state change listener
        return { error: null, user: response.data.user, session: response.data.session };
      }

      return { error: { message: 'OTP verification failed' } };
    } catch (error) {
      return { error: { message: 'An unexpected error occurred. Please try again.' } };
    }
  };

  const signOut = async () => {
    await supabase.auth.signOut();
  };

  const value = {
    user,
    session,
    userProfile,
    isLoading,
    isAdmin,
    isCustomer,
    signIn,
    signUp,
    signOut,
    refreshProfile,
    hasRole,
    sendOtp,
    verifyOtp,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};