import React, { createContext, useContext, useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './AuthContext';
import { toast } from '@/hooks/use-toast';

interface CartItem {
  id?: string;
  product_id: string;
  quantity: number;
  product?: {
    id: string;
    name: string;
    price: number;
    sale_price: number | null;
    image_url: string | null;
    stock_quantity: number;
  };
}

interface CartContextType {
  cartItems: CartItem[];
  addToCart: (productId: string, quantity?: number) => Promise<void>;
  updateQuantity: (productId: string, quantity: number) => Promise<void>;
  removeFromCart: (productId: string) => Promise<void>;
  clearCart: () => Promise<void>;
  getTotalItems: () => number;
  getTotalPrice: () => number;
  isLoading: boolean;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const { user } = useAuth();

  // Load cart from localStorage on mount (for guest users)
  useEffect(() => {
    if (!user) {
      const savedCart = localStorage.getItem('guest_cart');
      if (savedCart) {
        try {
          setCartItems(JSON.parse(savedCart));
        } catch (error) {
          console.error('Error parsing saved cart:', error);
          localStorage.removeItem('guest_cart');
        }
      }
    }
  }, [user]);

  // Load cart from database for authenticated users
  useEffect(() => {
    if (user) {
      fetchCartFromDatabase();
      // Merge guest cart if exists
      mergeGuestCart();
    }
  }, [user]);

  // Save guest cart to localStorage
  useEffect(() => {
    if (!user && cartItems.length > 0) {
      localStorage.setItem('guest_cart', JSON.stringify(cartItems));
    }
  }, [cartItems, user]);

  const fetchCartFromDatabase = async () => {
    if (!user) return;

    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('cart_items')
        .select(`
          *,
          products:product_id (
            id,
            name,
            price,
            sale_price,
            image_url,
            stock_quantity
          )
        `)
        .eq('user_id', user.id);

      if (error) throw error;

      const formattedItems = data?.map(item => ({
        id: item.id,
        product_id: item.product_id,
        quantity: item.quantity,
        product: item.products
      })) || [];

      setCartItems(formattedItems);
    } catch (error) {
      console.error('Error fetching cart:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const mergeGuestCart = async () => {
    const guestCart = localStorage.getItem('guest_cart');
    if (!guestCart || !user) return;

    try {
      const guestItems: CartItem[] = JSON.parse(guestCart);
      for (const item of guestItems) {
        await addToCart(item.product_id, item.quantity);
      }
      localStorage.removeItem('guest_cart');
    } catch (error) {
      console.error('Error merging guest cart:', error);
    }
  };

  const addToCart = async (productId: string, quantity: number = 1) => {
    setIsLoading(true);
    try {
      if (user) {
        // Authenticated user - save to database
        const existingItem = cartItems.find(item => item.product_id === productId);
        
        if (existingItem) {
          const { error } = await supabase
            .from('cart_items')
            .update({ quantity: existingItem.quantity + quantity })
            .eq('id', existingItem.id);

          if (error) throw error;
        } else {
          const { error } = await supabase
            .from('cart_items')
            .insert({
              user_id: user.id,
              product_id: productId,
              quantity
            });

          if (error) throw error;
        }
        
        await fetchCartFromDatabase();
      } else {
        // Guest user - save to localStorage
        const existingItemIndex = cartItems.findIndex(item => item.product_id === productId);
        
        if (existingItemIndex >= 0) {
          const updatedItems = [...cartItems];
          updatedItems[existingItemIndex].quantity += quantity;
          setCartItems(updatedItems);
        } else {
          // Fetch product details for guest cart
          const { data: product } = await supabase
            .from('products')
            .select('id, name, price, sale_price, image_url, stock_quantity')
            .eq('id', productId)
            .single();

          if (product) {
            setCartItems(prev => [...prev, {
              product_id: productId,
              quantity,
              product
            }]);
          }
        }
      }

      toast({
        title: "Added to Cart",
        description: "Product added to your cart successfully",
      });
    } catch (error) {
      console.error('Error adding to cart:', error);
      toast({
        title: "Error",
        description: "Failed to add product to cart",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const updateQuantity = async (productId: string, newQuantity: number) => {
    if (newQuantity <= 0) {
      return removeFromCart(productId);
    }

    setIsLoading(true);
    try {
      if (user) {
        const cartItem = cartItems.find(item => item.product_id === productId);
        if (!cartItem?.id) return;

        const { error } = await supabase
          .from('cart_items')
          .update({ quantity: newQuantity })
          .eq('id', cartItem.id);

        if (error) throw error;
        await fetchCartFromDatabase();
      } else {
        const updatedItems = cartItems.map(item =>
          item.product_id === productId ? { ...item, quantity: newQuantity } : item
        );
        setCartItems(updatedItems);
      }
    } catch (error) {
      console.error('Error updating cart:', error);
      toast({
        title: "Error",
        description: "Failed to update cart",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const removeFromCart = async (productId: string) => {
    setIsLoading(true);
    try {
      if (user) {
        const cartItem = cartItems.find(item => item.product_id === productId);
        if (!cartItem?.id) return;

        const { error } = await supabase
          .from('cart_items')
          .delete()
          .eq('id', cartItem.id);

        if (error) throw error;
        await fetchCartFromDatabase();
      } else {
        const updatedItems = cartItems.filter(item => item.product_id !== productId);
        setCartItems(updatedItems);
      }

      toast({
        title: "Removed from Cart",
        description: "Product removed from your cart",
      });
    } catch (error) {
      console.error('Error removing from cart:', error);
      toast({
        title: "Error",
        description: "Failed to remove product from cart",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const clearCart = async () => {
    setIsLoading(true);
    try {
      if (user) {
        const { error } = await supabase
          .from('cart_items')
          .delete()
          .eq('user_id', user.id);

        if (error) throw error;
      } else {
        localStorage.removeItem('guest_cart');
      }
      
      setCartItems([]);
    } catch (error) {
      console.error('Error clearing cart:', error);
      toast({
        title: "Error",
        description: "Failed to clear cart",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const getTotalItems = () => {
    return cartItems.reduce((total, item) => total + item.quantity, 0);
  };

  const getTotalPrice = () => {
    return cartItems.reduce((total, item) => {
      const price = item.product?.sale_price || item.product?.price || 0;
      return total + (price * item.quantity);
    }, 0);
  };

  return (
    <CartContext.Provider value={{
      cartItems,
      addToCart,
      updateQuantity,
      removeFromCart,
      clearCart,
      getTotalItems,
      getTotalPrice,
      isLoading
    }}>
      {children}
    </CartContext.Provider>
  );
};